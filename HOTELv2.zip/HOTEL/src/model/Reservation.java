package model;

import java.util.Date;

public class Reservation {
    private Customer Customer;
    private IRoom room;
    private Date CheckInDate;
    private Date CheckOutDate;

    public Reservation(Customer customer, IRoom room, Date checkInDate, Date checkOutDate) {
        this.Customer=customer;
        this.room =room;
        this.CheckInDate=checkInDate;
        this.CheckOutDate=checkOutDate;

    }

    public IRoom getRoom() {
        return room;
    }

    public Customer getCustomer() {
        return Customer;
    }

    public Date getCheckOutDate() {
        return CheckOutDate;
    }

    public Date getCheckInDate() {
        return CheckInDate;
    }

    @Override
    public String toString() {
        return "Reservation is : \n " +
                "Customer info :" + Customer +
                "\n FreeRoom.Room :" + room +
                "\n Check in Date :" + CheckInDate +
                "\n Check Out Date :" + CheckOutDate ;
    }
}
