package model;

public enum RoomType
{SINGLE,
    DOUBLE}
