package model;

public class FreeRoom extends Room {

    private  String roomNumber;
    private double price;
    private RoomType enumertion;
    boolean isFree;


    public FreeRoom(String roomNumber, double price, RoomType enumertion) {
        super(roomNumber, 0 , enumertion);
    }

    public String toString() {
        return "FreeRoom: \n " +
                "room Number:" + roomNumber +
                ",room Type :" + enumertion +
                ", Available :" + isFree
                ;
    }

    @Override
    public String getRoomNumber() {
        return roomNumber;
    }

}
