package service;

import model.Customer;

import java.util.*;

public class CustomerService {


    //static reff
     static final CustomerService reference = new CustomerService();
    private final Map< String, Customer> customers = new HashMap<>();

    public static CustomerService getReference() {
       return reference;
    }

    //1----- done -----
    public void addCustomer(String email, String firstName, String lastName) {

        Customer newCustomer = new Customer(firstName, lastName, email);
        customers.put(email,newCustomer);
    }

//2----done-----
    public Customer getCustomer(String customerEmail) {
        return customers.get(customerEmail);

    }
    //3-
    public Collection<Customer> getAllCustomer() {
        return customers.values();
    }

}





