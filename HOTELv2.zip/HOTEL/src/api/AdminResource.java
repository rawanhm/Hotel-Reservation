package api;

import model.Customer;
import model.IRoom;
import model.Reservation;
import service.CustomerService;
import service.ReservationService;

import java.util.Collection;
import java.util.List;

public class AdminResource {

    //static reff
    static final AdminResource AdminResource = new AdminResource();
    static CustomerService customerService = CustomerService.getReference();
    static ReservationService reservationService = ReservationService.getReference();


    public static AdminResource getAdminResource() {
        return AdminResource;
    }

    //1-
    public Customer getCustomer(String email) {
        return customerService.getCustomer(email);
    }

    //2-
    public void addRoom(List<IRoom> rooms) {
        for (IRoom room : rooms) {reservationService.addRoom(room);}

    }

    //3-
    public Collection<IRoom> getAllRooms() {return reservationService.getAllRooms();

    }

    //4--done---
    public Collection<Customer> getAllCustomers() {
        return customerService.getAllCustomer();
    }

    //5-
    public static List<Reservation> AllReservations(){
        return reservationService.AllReservations();
    }
    public static void displayAllReservations(){
        List<Reservation> reservations =AllReservations();
        if (reservations != null) { System.out.println("No room reserved");}
        for (Reservation reservation : reservations) {
            System.out.println(reservation + "\n");
        }
    }

}

