package api;

import model.Customer;
import model.IRoom;
import model.Reservation;
import service.CustomerService;
import service.ReservationService;

import java.util.Collection;
import java.util.Collections;
import java.util.Date;




public class HotelResource {



//static reff
static  HotelResource HotelResource = new HotelResource();

    static CustomerService customerService = CustomerService.getReference();
    static ReservationService reservationService = ReservationService.getReference();

    //1-- done ----
    public Customer getCustomer(String email) {
        return customerService.getCustomer(email);
    }

    //2-- done ---
    public void createACustomer(String email, String firstName, String lastName) {
        customerService.addCustomer(email,firstName,lastName);
    }

    //3-- done---
    public IRoom getRoom(String roomNumber) {
        return reservationService.getARoom(roomNumber);
    }

    //4-- done ---
    public Reservation bookARoom(String customerEmail, IRoom room, Date checkInDate, Date checkOutDate) {
        return reservationService.reserveARoom(getCustomer(customerEmail), room, checkInDate, checkOutDate);
    }

    //5-- done ----
    public Collection<Reservation> getCustomersReservations(String customerEmail) {
        Collection<Reservation> Collections = null;
        Customer customer = getCustomer(customerEmail);
        if (customer != null){
            Collections =reservationService.getCustomerReservations(customer) ;
        }
        return Collections;
    }


    //6--
    public Collection<IRoom> findARooms(Date checkIn, Date checkOut) {
        return reservationService.findRooms(checkIn,checkOut);
    }

    public static HotelResource getHotelResource() {
        return HotelResource;
    }
}
