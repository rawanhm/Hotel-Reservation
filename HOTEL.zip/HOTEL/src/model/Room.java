package model;

import java.util.Objects;

public class Room implements IRoom {
    String roomNumber;
    double price;
    RoomType enumertion;
    boolean isFree;

    public Room(String roomNumber, double price, RoomType enumertion) {
        this.price = price;
        this.roomNumber = roomNumber;
        this.enumertion = enumertion;
        this.isFree = true;
    }

    @Override
    public String getRoomNumber() {
        return roomNumber;
    }

    public boolean isFree() {
        return this.isFree;
    }

    public void setFree(boolean free) {
        isFree = free;
    }

    public RoomType getRoomType() {
        return null;
    }

    public double getRoomPrice() {
        return price;
    }

    public String toString() {
        return "Room: \n " +
                "room Number:" + roomNumber +
                ", price:" + price + ", room Type :" + String.valueOf(enumertion) + ", Available :" + isFree;
    }
    public boolean equals(Object obj) {
        if(obj == this) {
            return true;
        }

        if(!(obj instanceof Room)) {
            return false;
        }

        final Room room = (Room) obj;
        return Objects.equals(this.roomNumber, room.roomNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(roomNumber);
    }


}