package Menu;

import api.HotelResource;
import model.IRoom;
import model.Reservation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Scanner;

public class MainMenu {
    static Scanner scanner = new Scanner(System.in);
    static HotelResource hotelResource =HotelResource.getHotelResource();

    public  static void mainMenu() {
        String input;

        //=========================printing  mune==================================
        System.out.print(
                "--------------------------------------------\n" +
                "1. Find and reserve a room\n" +
                "2. See my reservations\n" +
                "3. Create an Account\n" +
                "4. Admin\n" +
                "5. Exit\n" +
                "--------------------------------------------\n" +
                "Please select a number for the menu option:\n");
        //===========================================================

        try {
            do {
                input = scanner.nextLine();

                if (input.length() == 1) {
                    switch (input.charAt(0)) {
                        case '1':
                             findAndReserveRoom();
                            break;
                        case '2':
                            seeMyReservation();
                            mainMenu();
                            break;
                        case '3':
                            CreateAccount();
                            mainMenu();
                            break;
                        case '4':
                             AdminMenu.adminMenu();
                            break;
                        case '5':
                            System.out.println("Exit");
                            System.exit(0);
                            break;
                        default:
                            System.out.println("Unknown action\n");
                            break;
                    }
                } else {
                    System.out.println("Invalid action\n");
                }
            } while (input.charAt(0) != '5' || input.length() != 1);
        } catch (StringIndexOutOfBoundsException ex) {
            System.out.println("No input received ,End program");
            System.exit(0);
        }
    }



    //1-recheck
    private static void findAndReserveRoom() {

        Date In = null;
        Date Out=null;
        Collection<IRoom> avaRooms;

        System.out.println("Enter Check-In Date dd/MM/yyyy example 07/11/2022");

        try {
            String checkIn = scanner.nextLine();
            In = new SimpleDateFormat("dd/MM/yyyy").parse(checkIn);
        } catch (ParseException ex) {
            System.out.println("Error: Invalid date.");
        }
        System.out.println("Enter Check-Out Date dd/MM/yyyy example 07/11/2022");

        try {
                String checkOut = scanner.nextLine();
                Out = new SimpleDateFormat("dd/MM/yyyy").parse(checkOut);
            } catch (ParseException exp) {
                System.out.println("Error: Invalid date.");
            }

        if (In != null && Out != null) {
           avaRooms = hotelResource.findARooms(In, Out);

            if (avaRooms.isEmpty()) {
                System.out.println("No rooms found.");
            } else {
                System.out.println("the Available rooms :");
                for (IRoom room :avaRooms ) {
                    System.out.println(room + "\n");
                }
                reserve( In, Out);
        }}
    }
         public static void reserve(Date in, Date out) {
             System.out.println("Would you like to book? y/n");
             String bookRoom = scanner.next().toUpperCase();

             if ("Y".equals(bookRoom)) {
                 System.out.println("Do you have an account with us? y/n");
                 String have = scanner.next().toUpperCase();
                 if ("Y".equals(have)) {
                     System.out.println("Enter Email format: name@domain.com");
                           String customerEmail = scanner.nextLine();
                           if (hotelResource.getCustomer(customerEmail) != null) {
                               boolean free=true;
                               while(free){
                                   System.out.println("What room number would you like to reserve?");
                                   final String roomNumber = scanner.nextLine();

                                   if (hotelResource.getRoom(roomNumber)!=null ) {
                                       final IRoom room = hotelResource.getRoom(roomNumber);
                                       if (room.isFree()) {
                                           Reservation reserve= hotelResource.bookARoom(customerEmail,room ,in,out ) ;
                                           System.out.println("Reservation created successfully!");
                                           System.out.println(reserve);
                                           free= false;
                                       } else {
                                           System.out.println("the room you choose not free please enter other room number");
                                       }
                                   }}//while

                              } else {
                               System.out.println("Customer not found.\n" +
                                       "You may need to create a new account." +
                                       "\n back to main menu and enter 3 to create new account !!");
                               mainMenu();}//have email not correct

                     }//have account
                 }
             }



    //2---done----
    private static void seeMyReservation() {
        System.out.println("Enter your Email :\n");
        String email = scanner.nextLine();
        hotelResource.getCustomersReservations(email);
    }

        //3-000000done
        protected static void CreateAccount() {
            System.out.println("Enter your Email :\n");
            String email = scanner.nextLine();
            System.out.println("Enter your First Name:");
            String firstName = scanner.nextLine();
            System.out.println("Enter your Last Name:");
            String lastName = scanner.nextLine();

            hotelResource.createACustomer(email, firstName, lastName);
            System.out.println("Customer created successfully");

        }
    }

