package Menu;

import api.AdminResource;
import model.*;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class AdminMenu {

    static AdminResource AdminResource = api.AdminResource.getAdminResource();


    public static void adminMenu() {
        String input ;
         Scanner scanner = new Scanner(System.in);

        //=========================printing  mune====================
        System.out.print("\nAdmin Menu\n" +
                "--------------------------------------------\n" +
                "1. See all Customers\n" +
                "2. See all Rooms\n" +
                "3. See all Reservations\n" +
                "4. Add a Room\n" +
                "5. Back to Main Menu\n" +
                "--------------------------------------------\n" +
                "Please select a number for the menu option:\n");
        //===========================================================

        try {
            do {
                input = scanner.nextLine();

                if (input.length() == 1) {
                    switch (input.charAt(0)) {
                        case '1':
                            displayAllCustomers();
                            adminMenu();
                            break;
                        case '2':
                            displayAllRooms();
                            adminMenu();
                            break;
                        case '3':
                            displayAllReservations();
                            adminMenu();
                            break;
                        case '4':
                            addRoom();
                            break;
                        case '5':
                            MainMenu.mainMenu();
                            break;
                        default:
                            System.out.println("Unknown input\n");
                            break;
                    }
                } else {
                    System.out.println("Invalid action\n");
                }
            } while (input.charAt(0) != '5' || input.length() != 1);
        } catch (StringIndexOutOfBoundsException ex) {
            System.out.println("No input received ,End program");
            System.exit(0);
        }
    }
    //1. See all Customers 000000000000000000000
    public static void displayAllCustomers() {

        Collection<Customer> customers = AdminResource.getAllCustomers();

        if (customers.isEmpty()) {
            System.out.println("No customers found.");
        } else {
            if(customers == null){
                System.out.println("No room reserved");
            }else{
                for (Customer customer : customers) {
                    System.out.println(customer + "\n");
                }
            }

        }
    }
    //2. See all Rooms 0000000000
    public static void displayAllRooms() {
        Collection<IRoom> rooms = AdminResource.getAllRooms();

        if(rooms.isEmpty()) {
            System.out.println("No rooms found.");
        } else {
            for (IRoom room : rooms) {
                System.out.println(room);
        }}
    }
    //3. See all Reservations00000000000000
    public static void displayAllReservations(){
        AdminResource.displayAllReservations();
    }
    //4. Add a Room00000000000000000000000011
     static   void addRoom() {
         Scanner scanner = new Scanner(System.in);

        System.out.println("Enter room number:");
         String roomNumber = scanner.nextLine();

        System.out.println("Enter price per night:");
         double roomPrice = Double.parseDouble(scanner.nextLine());

        System.out.println("Enter room type: 'single' bed,  'double'  bed :");
         RoomType roomType = RoomType.valueOf(scanner.nextLine().toUpperCase());

         Room room = new Room(roomNumber, roomPrice, roomType);

        AdminResource.addRoom(Collections.singletonList(room));
        System.out.println("Room added successfully!");
        System.out.println("Would like to add another room? Y/N");
        String newRoom = scanner.nextLine().toUpperCase();
        switch (newRoom.charAt(0)) {
            case 'Y': addRoom();
            case 'N': adminMenu();
            default:
           System.out.println(" Invalid action, back to menu ");
           adminMenu();
        }
    }


}
