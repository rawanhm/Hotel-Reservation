package service;

import model.Customer;

import java.util.*;

public class CustomerService {


    //static reff
     static final CustomerService reference = new CustomerService();
    Collection<Customer> customers =  new LinkedList<Customer>();

    public static CustomerService getReference() {
       return reference;
    }

    //1----- done -----
    public void addCustomer(String email, String firstName, String lastName) {
        Customer newCustomer = new Customer(firstName, lastName, email);
        customers.add(newCustomer);
    }

//2----done-----
    public Customer getCustomer(String customerEmail) {
        for (Customer Customer:customers) {
            if(Customer.getEmail().equals(customerEmail)){
                return Customer;
        }}
        return null;
    }
    //3-
    public Collection<Customer> getAllCustomer() {
        return customers;
    }

}





