package service;

import model.Customer;
import model.IRoom;
import model.Reservation;

import java.util.*;
import java.util.stream.Collectors;

public class ReservationService {

    static final ReservationService reference = new ReservationService();
    private Map<String, IRoom> rooms = new HashMap<String, IRoom>();

     public Map<String, List<Reservation>> map = new HashMap<String, List<Reservation>>();
    //be sure
    public static ReservationService getReference() {
    return reference;
}

    public Collection<IRoom> roomList = new LinkedHashSet<IRoom>();

    //1
    public void addRoom(IRoom room)
    {
        rooms.put(room.getRoomNumber(),room);
        roomList.add(room);
    }
    //2---done ----
    public IRoom getARoom(String roomId) {
     return rooms.get(roomId);
    }
    //3
    public Reservation reserveARoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate) {

        room.setFree(false);
        Reservation reservation = new Reservation(customer, room, checkInDate, checkOutDate);

        List<Reservation> customersReservation = map.get(customer.getEmail());

        if(customersReservation != null){
            customersReservation.add(reservation);
            map.put(customer.getEmail(), customersReservation);

        }else {
            customersReservation = new ArrayList<>();
        }

        return reservation;
    }
    //4
    public Collection<IRoom> findRooms(Date checkInDate, Date checkOutDate) {

        List<Reservation> allReservations = AllReservations();
        Collection<IRoom> notAvailableRooms = new LinkedList<IRoom>();

        for (Reservation reservation : allReservations) {
            if (checkInDate.before(reservation.getCheckOutDate())
                    && checkOutDate.after(reservation.getCheckInDate())) {
                notAvailableRooms.add(reservation.getRoom());
            }
        }
        Collection<IRoom> Availablerooms=
                rooms.values().stream().filter(
                        room -> notAvailableRooms.stream().noneMatch(notAvailableRoom -> notAvailableRoom.equals(
                                room))).collect(Collectors.toList());
        return Availablerooms;
    }



        //5  ----done ---
        public Collection<Reservation> getCustomerReservations(Customer customer){
            return map.get(customer.getEmail());
        }
        //6  ---done-----
        public List<Reservation> AllReservations () {
            List<Reservation> allCustomerReservation = new ArrayList<>();
            for (List<Reservation> reservation : map.values()) {
                allCustomerReservation.addAll(reservation);
            }
            return allCustomerReservation;
        }




    }



