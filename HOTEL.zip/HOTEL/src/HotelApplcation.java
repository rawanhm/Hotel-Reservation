import Menu.MainMenu;

public class HotelApplcation {

    public static void main(String[] args) {
        System.out.println("\n Welcome to Rawan Hotel Reservation Application \n Main Menu \n ");
        MainMenu.mainMenu();
    }
}
