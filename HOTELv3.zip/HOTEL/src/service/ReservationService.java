package service;

import model.Customer;
import model.IRoom;
import model.Reservation;

import java.util.*;
import java.util.stream.Collectors;

public class ReservationService {

    static final ReservationService reference = new ReservationService();
    private final Map<String, IRoom> rooms = new HashMap<>();

     public Map<String, Collection<Reservation>> map = new HashMap<>();

    public static ReservationService getReference() {
    return reference;
}



    //1 EEE
    public void addRoom(IRoom room) {
        rooms.put(room.getRoomNumber(),room);

    }
    //2-EEE
    public IRoom getARoom(String roomId) {
     return rooms.get(roomId);
    }
    //3
    public Reservation reserveARoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate) {

        //room.setFree(false);
        Reservation reservation = new Reservation(customer, room, checkInDate, checkOutDate);

        Collection<Reservation> customersReservation = getCustomerReservations(customer);

        if(customersReservation == null) customersReservation = new LinkedList<>();

            customersReservation.add(reservation);
            map.put(customer.getEmail(), customersReservation);


        return reservation;
    }
    //4
    public Collection<IRoom> findRooms(Date checkInDate, Date checkOutDate) {

        List<Reservation> allReservations = AllReservations();
        Collection<IRoom> notAvailableRooms = new LinkedList<>();

        for (Reservation reservation : allReservations) {
            if (checkInDate.before(reservation.getCheckOutDate())
                    && checkOutDate.after(reservation.getCheckInDate())) {
                notAvailableRooms.add(reservation.getRoom());
            }
        }
        Collection<IRoom> Availablerooms=
                rooms.values().stream().filter(
                        room -> notAvailableRooms.stream().noneMatch(notAvailableRoom -> notAvailableRoom.equals(
                                room))).collect(Collectors.toList());
        return Availablerooms;
    }


        //5  ----done ---
        public Collection<Reservation> getCustomerReservations(Customer customer){
            return map.get(customer.getEmail());
        }

        //6  ---done-----
        public List<Reservation> AllReservations() {

            List<Reservation> allCustomerReservation = new ArrayList<>();
            for (Collection<Reservation> reservation : map.values()) {
                allCustomerReservation.addAll(reservation);
            }
            return allCustomerReservation;
        }


         public Collection<IRoom> getAllRooms() {
      return rooms.values();
    }
}



