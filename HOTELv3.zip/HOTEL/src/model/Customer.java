package model;

import java.util.regex.Pattern;

public class Customer {
    private  final String firstName;
    private  final String lastName;
    private final String email;

    public Customer(String firstName, String lastName, String email){
    this.firstName=firstName;
    this.lastName=lastName;
    this.email=email;
    String emailRegex = "^(.+)@(.+).(.+)$";
    Pattern pattern = Pattern.compile(emailRegex);
    if(!pattern.matcher(email).matches())
       throw new IllegalArgumentException("The email format only like name@domain.com");
}
//getter and setter

    public String getEmail() {
        return email;
    }



    public String getFirstName() {
        return firstName;
    }




    public String getLastName() {
        return lastName;
    }



    @Override
    public String toString() {
        return "Customer :\n " +
                "firstName= " + firstName +
                ",  lastName=" + lastName  +
                ", email=" + email ;
    }
}
